<!DOCTYPE html>
<html lang="en" class="no-js">
  <head>
    <meta charset="utf-8">
    
<script type="text/javascript" src="https://cdn.cookielaw.org/consent/b680e9a8-3d45-4e4a-998f-7d05f89e4486/OtAutoBlock.js" ></script>
<script src="https://cdn.cookielaw.org/scripttemplates/otSDKStub.js" data-document-language="true" type="text/javascript" charset="UTF-8" data-domain-script="b680e9a8-3d45-4e4a-998f-7d05f89e4486" ></script>
<script type="text/javascript" type="text/javascript" src="https://static3.avast.com/20001375/web/j/vendor/one-trust.js"></script>


<script>
    /*! Declare GTM dataLayer */
    window.dataLayer = window.dataLayer || [];
      
    /*! Dimensions to dataLayer */
    (function(){
        var dataObj = {
            'contentLocale': 'en-us',
            'pageName': 'en-us | en-us/error-page.php',
            'pageId': 'ad4617d2e34aa8abc46f8ba444ff9921'
        };
        var contentGroup = '';
        if (contentGroup != '') {
            dataObj.contentGroup = contentGroup;
        }
      
     	var pageGroup = '';
        if (pageGroup != '') {
            dataObj.pageGroup = pageGroup;
        }
        
        dataLayer.push(dataObj);
    })();
    </script>
    

<style>.async-hide { opacity: 0 !important} </style>
<script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
(a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
})(window,document.documentElement,'async-hide','dataLayer',2000,
{'GTM-PZ48F8':true});</script>


<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PZ48F8');</script>


    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    
    
    <meta name="google-site-verification" content="yuuaBgRMbmDWxp2V7VtQB4P1drBU3VFilCfm-w9lYVY">
    
    
    <meta name="google-site-verification" content="745mlgYwirfw8dcmobUYosqPQycy7KubvwtIe9rtkr0" />
    
    <link rel="canonical" href="https://www.avast.com/en-us/error-page.php">
    
    
<link rel="icon" type="image/png" href="https://static3.avast.com/20001375/web/i/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="https://static3.avast.com/20001375/web/i/favicon-16x16.png" sizes="16x16" />
    
	<link rel="apple-touch-icon" href="https://static3.avast.com/20001375/web/i/apple-touch-icon-57x57.png" />
	<link rel="apple-touch-icon" sizes="76x76" href="https://static3.avast.com/20001375/web/i/apple-touch-icon-76x76.png" />
	<link rel="apple-touch-icon" sizes="120x120" href="https://static3.avast.com/20001375/web/i/apple-touch-icon-120x120.png" />
	<link rel="apple-touch-icon" sizes="152x152" href="https://static3.avast.com/20001375/web/i/apple-touch-icon-152x152.png" />
    
<meta name="application-name" content="Avast Antivirus"/>
<meta name="msapplication-TileColor" content="#2d364c" />
<meta name="msapplication-square150x150logo" content="https://static3.avast.com/20001375/web/i/mstile-150x150.png" />
<meta name="msapplication-square310x310logo" content="https://static3.avast.com/20001375/web/i/mstile-310x310.png" />
    
<meta content="https://static3.avast.com/20001375/web/i/mkt/share/avast-logo.png" property="og:image"/>
    
    
    <link href="https://static3.avast.com/20001375/web/c/v2/avast.css" rel="stylesheet" media="all">

    
    
    
    
    
    
    
    
    
    
    
    
    
    
	
    
    
    <title>Page not found</title>
		<link href="https://static3.avast.com/20001375/web/c/v2/avast/layout/common.css" media="all" rel="stylesheet"/>
<link href="https://static3.avast.com/20001375/web/c/mkt/error-page-3-2021.css" media="all" rel="stylesheet" type="text/css"/>
	
    
    <link href="https://static3.avast.com/20001375/web/c/download-popup.css" media="all" rel="stylesheet"/>
    
    <link href="https://static3.avast.com/20001375/web/c/v2/avast/local/en-us/local.css" rel="stylesheet" media="all">
    
<script nomodule src="https://cdn.polyfill.io/v2/polyfill.min.js"></script>
	
    <script>
        document.documentElement.className = document.documentElement.className.replace("no-js","js");
    </script>
  </head>
  
  <body class="tmpl-www mod-en-us">
    

<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PZ48F8"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>


    <noscript>
        <div class="noscript-message">In order to view this page correctly, you must have a JavaScript-enabled browser and have JavaScript turned on. We apologize for any inconvenience. <a href="//support.google.com/adsense/bin/answer.py?hl=en&answer=12654">Learn how to enable it</a>.</div>
</noscript>
    <div class="unsupported-browser-message">
  <div class="container">
    	<p>We’re sorry, your browser appears to be outdated.<br>To see the content of this webpage correctly, please update to the latest version or install a new browser for free, such as <a href="/en-us/secure-browser">Avast Secure Browser</a> or <a href="https://www.google.com/chrome/">Google Chrome</a>.</p>
  </div>
</div>  
	
	





	
    

<div class="navigation-mobile-overlay"></div>
<header data-cmp-name="cmp-header" class="js-navigation-bootstrap header relative default web js-navigation-oo-19798 navigation-oo-19798">
  <div class="header-wrap">

  <div class="avast-logo">
    <a target="_parent" title="Home" href="/en-us/index" data-role="Nav:TopLink" data-cta="logo">

      <img width="113" height="36" alt="Avast" src="https://static3.avast.com/20001375/web/i/v2/components/logos/avast-logo-default.svg">

    </a>
  </div>


  
   <button class="reader-only" href="#main-content">Skip to main content</button>

  
  <button class="js-toggle-menu hidden-desktop toggle-menu  bi-nav-menu" data-nav-mobile-toggle="open" aria-label="Open or close navigation menu"><span>>Close</span></button>


  <nav>

    
    <div class="first-menu">

      <ul class="side" role="menubar">

        <li class="item for-home bi-nav-menu" data-first-menu="for-home" data-bi-nav="Home" role="none">
          <a class="category for-home hidden-mobile" href="/en-us/index" data-role="Nav:TopLink" data-cta="home" tabindex="0" role="menuitem">For home</a>
          <span class="category hidden-desktop">For home</span>
          <span class="text hidden-desktop">Products for PC and mobile phone protection</span>
        </li>
        <li class="item for-business bi-nav-menu" data-first-menu="for-business" data-bi-nav="Business" role="none">
          <a class="category for-business hidden-mobile" href="/en-us/business" data-role="Nav:TopLink" data-cta="business" tabindex="0" role="menuitem">For business</a>
          <span class="category hidden-desktop">For business</span>
          <span class="text hidden-desktop">Protect your business with Avast</span>
        </li>
        <li class="item for-partners bi-nav-menu" data-first-menu="for-partners" data-bi-nav="Partners" role="none">
          <a class="category for-partners hidden-mobile" href="/en-us/partners" data-role="Nav:TopLink" data-cta="partners" tabindex="0" role="menuitem">For partners</a>
          <span class="category hidden-desktop">For partners</span>
          <span class="text hidden-desktop">Partner with Avast and boost your business</span>
        </li>
      </ul>

      <ul class="side" role="menubar">

        <li class="item about-us bi-nav-menu" data-first-menu="about-us" data-bi-nav="About" role="none">
          <a class="category about-us hidden-mobile" href="/en-us/about" data-role="Nav:TopLink" data-cta="about" tabindex="0" role="menuitem">About us</a>
          <span class="category hidden-desktop" role="menuitem">About us</span>
          <span class="text hidden-desktop">Careers, investors, media, contact</span>
        </li>
        <li class="js-blogs item blogs arrow bi-nav-menu" data-bi-nav="Blogs" role="none">
          <span class="category" tabindex="0" role="menuitem">Blogs</span>
          <span class="text hidden-desktop">Academy, Blog, Decoded, Forum</span>
        </li>


        <li class="item region arrow en-us js-language-selector-trigger bi-nav-menu" data-first-menu="regions" data-bi-nav="Regions" role="none">
          <a class="with-flag category" tabindex="0" aria-label="United States (English) opens dialog" role="menuitem">United States (English)</a>
        </li>

      </ul>

    </div>
    


    

    
    <div class="second-menu for-home">
      <div class="js-back mobile back">For home</div>

      
      <ul class="side" role="menubar">

        
        <li data-second-menu="security" role="none">
          <span class="subcategory security arrow" tabindex="0" role="menuitem" aria-expanded="false" aria-controls="security">Security</span>

          
          <div class="third-menu security" role="menu" id="navigation-security">
            <ul class="block-products">
              <li>
                
                <a href="/en-us/free-antivirus-download" class="content-windows" data-role="Nav:MenuItem" data-cta="homeSecurity">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-free_white.svg" title="Free Antivirus">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/free-antivirus.svg" alt=""><span class="product-name">Free Antivirus</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Basic protection for all your devices</span>
                </a>
                
                <a href="/en-us/free-mac-security" class="content-mac" data-role="Nav:MenuItem" data-cta="homeSecurity">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-free_white.svg" title="Free Antivirus">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/free-antivirus.svg" alt=""><span class="product-name">Free Antivirus</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Basic protection for all your devices</span>
                </a>
                
                <a href="/en-us/free-mobile-security" class="content-android" data-role="Nav:MenuItem" data-cta="homeSecurity">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-free_white.svg" title="Free Antivirus">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/free-antivirus.svg" alt=""><span class="product-name">Free Antivirus</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Basic protection for all your devices</span>
                </a>
                
                <a href="/en-us/free-ios-security" class="content-ios" data-role="Nav:MenuItem" data-cta="homeSecurity">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-free_white.svg" title="Free Antivirus">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/free-antivirus.svg" alt=""><span class="product-name">Free Antivirus</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Basic protection for all your devices</span>
                </a>
              </li>
              <li>
                <a href="/en-us/premium-security" data-role="Nav:MenuItem" data-cta="homeSecurity">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-premium_white.svg" title="Free Antivirus">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/premium.svg" alt=""><span class="product-name">Premium Security</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Complete protection against all internet threats</span>
                </a>
              </li>
              <li>
                
                <a href="/en-us/ultimate" data-role="Nav:MenuItem" data-cta="homeBundles">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-ultimate_white.svg" title="Ultimate">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/free-antivirus.svg" alt=""><span class="product-name">Ultimate</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Our best security, privacy, and performance apps in one package</span>
                </a>
              </li>
            </ul>

             
            <p class="hint hidden-mobile">Looking for a product for your device? <a href="/en-us/free-antivirus-download" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Antivirus&nbsp;for&nbsp;PC</a>, <a href="/en-us/free-mobile-security" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Security&nbsp;for&nbsp;Android</a>, <a href="/en-us/free-mac-security" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Security&nbsp;for&nbsp;Mac</a>, <a href="/en-us/free-ios-security" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Security&nbsp;for&nbsp;iPhone/iPad</a></p>

            
            <p class="js-hint hint hidden-desktop">
              <span class="js-hint-close close-hint"></span>
              <span class="js-hint-toggler hint-title">Looking for a product for your device?</span>
              <span class="hint-content">
                <a href="/en-us/free-antivirus-download" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Antivirus&nbsp;for&nbsp;PC</a>
                <a href="/en-us/free-mac-security" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Security&nbsp;for&nbsp;Mac</a>
                <a href="/en-us/free-mobile-security" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Security&nbsp;for&nbsp;Android</a>
                <a href="/en-us/free-ios-security" data-role="Nav:MenuItem" data-cta="homeSecurityLink">Free&nbsp;Security&nbsp;for&nbsp;iPhone/iPad</a>
              </span>
            </p>

          </div>
          

        </li>

        
        <li data-second-menu="privacy" role="none">
          <span class="subcategory privacy arrow" tabindex="0" role="menuitem" aria-expanded="false" aria-controls="privacy">Privacy</span>

          
          <div class="third-menu privacy" role="menu" id="navigation-privacy">
            <ul class="block-products">

              <li>
                <a href="/en-us/secureline-vpn" data-role="Nav:MenuItem" data-cta="homePrivacy">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-vpn_white.svg" title="SecureLine VPN">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/secure-line.svg" alt=""><span class="product-name">SecureLine VPN</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Encrypt your connection to stay safe on public networks</span>
                </a>
              </li>

              <li>
                <a href="/en-us/antitrack" data-role="Nav:MenuItem" data-cta="homePrivacy">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-anti-track_white.svg" title="AntiTrack">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/anti-track.svg" alt=""><span class="product-name">AntiTrack</span></span>
                  
<span class="os win mac android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Disguise your digital fingerprint to avoid personalized ads</span>
                </a>
              </li>
              <li>
                <a href="/en-us/secure-browser" data-role="Nav:MenuItem" data-cta="homePrivacy">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-secure-browser_white.svg" title="Secure Browser">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/secure-browser.svg" alt=""><span class="product-name">Secure Browser</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Secure, private and easy to use</span>
                </a>
              </li>
              <li>
                <a href="/en-us/breachguard" data-role="Nav:MenuItem" data-cta="homePrivacy">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-breach-guard_white.svg" title="BreachGuard">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/breachguard.svg" alt=""><span class="product-name">BreachGuard</span></span>
                  
<span class="os win mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Protect your personal info from being exposed and sold</span>
                </a>
              </li>
            </ul>
          </div>
          
        </li>

        
        <li data-second-menu="performance" role="none">
          <span class="subcategory performance arrow" tabindex="0" role="menuitem" aria-expanded="false" aria-controls="performance">Performance</span>
          
          <div class="third-menu performance" role="menu" id="navigation-performance">
            <ul class="block-products">
              <li>
                
                <a href="/en-us/cleanup" class="content-windows" data-role="Nav:MenuItem" data-cta="homePerformance">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-clean-up-premium_white.svg" title="Cleanup Premium">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/cleanup.svg" alt=""><span class="product-name">Cleanup Premium</span></span>
                  
<span class="os win mac android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Boost your computer’s speed and performance</span>
                </a>
                
                <a href="/en-us/cleanup-mac" class="content-mac" data-role="Nav:MenuItem" data-cta="homePerformance">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-clean-up-premium_white.svg" title="Cleanup Premium">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/cleanup.svg" alt=""><span class="product-name">Cleanup Premium</span></span>
                  
<span class="os win mac android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Boost your computer’s speed and performance</span>
                </a>
                
                <a href="/en-us/cleanup-android" class="content-android" data-role="Nav:MenuItem" data-cta="homePerformance">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-clean-up-premium_white.svg" title="Cleanup Premium">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/cleanup.svg" alt=""><span class="product-name">Cleanup Premium</span></span>
                  
<span class="os win mac android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Boost your computer’s speed and performance</span>
                </a>
                
                <a href="/en-us/cleanup" class="content-ios" data-role="Nav:MenuItem" data-cta="homePerformance">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-clean-up-premium_white.svg" title="Cleanup Premium">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/cleanup.svg" alt=""><span class="product-name">Cleanup Premium</span></span>
                  
<span class="os win mac android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Boost your computer’s speed and performance</span>
                </a>
              </li>
              <li>
                <a href="/en-us/driver-updater" data-role="Nav:MenuItem" data-cta="homePerformance">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-driver-updater_white.svg" title="Driver Updater">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/driver-updater.svg" alt=""><span class="product-name">Driver Updater</span></span>
                  
<span class="os win">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Automatically update drivers with a single click</span>
                </a>
              </li>
              <li>
                <a href="/en-us/battery-saver-for-windows" data-role="Nav:MenuItem" data-cta="homePerformance">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-battery-saver_white.svg" title="Battery Saver">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/battery-saver.svg" alt=""><span class="product-name">Battery Saver</span></span>
                  
<span class="os win">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Maximize your battery life </span>
                </a>
              </li>
            </ul>
          </div>
          
        </li>
        
        <li data-second-menu="family" role="none">
          
			  <span class="subcategory family arrow" tabindex="0" role="menuitem" aria-expanded="false" aria-controls="family">
              Family & Home          
            </span>
          
          <div class="third-menu family" role="menu" id="navigation-family">
            <ul class="block-products">
			  
			  
			  
			  
              <li>
                <a href="/en-us/omni" data-role="Nav:MenuItem" data-cta="homeSecurity">
                  <span class="name mobile-link">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-omni_white.svg" title="Omni">
</div><img class="logo" src="https://static3.avast.com/20001375/web/i/navigation/logo/omni.svg" alt=""><span class="product-name">Omni</span></span>
                  
<span class="os win mac android ios">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span>
                  <span class="description">Protects you everywhere you connect</span>
                </a>
              </li>
            </ul>
          </div>
          
        </li>
        
        <li role="none">
          <a class="desktop" href="/en-us/store" data-role="Nav:MenuItem" data-cta="homeShop" role="menuitem"><span class="subcategory shop">
            <img class="hidden-mobile" src="https://static3.avast.com/20001375/web/i/v2/components/navigation/cart.svg" alt="">Store
            </span></a>
        </li>
      </ul>

      
      <ul class="side mobile-links-top" role="menubar">
        <li class="mobile" role="menuitem">

          <a href="/en-us/index" data-role="Nav:MenuItem" data-cta="home" role="menuitem"><span class="subcategory home"><img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-home.svg" alt="">Home</span></a>
        </li>
        <li role="menuitem">
          <a href="https://support.avast.com" data-role="Nav:MenuItem" data-cta="homeSupport" role="menuitem"><span class="subcategory support"><img class="hidden-mobile" src="https://static3.avast.com/20001375/web/i/v2/components/navigation/support.svg" alt=""><img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-support.svg" alt="">Support</span></a>
        </li>
        <li role="menuitem">
          <a class="mobile" href="/en-us/store" data-role="Nav:MenuItem" data-cta="homeShop" role="menuitem"><span class="subcategory shop">
            <img src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-store.svg" alt="">

            Store
            </span></a>
        </li>
        <li role="menuitem">
          <a href="https://my.avast.com" data-role="Nav:MenuItem" data-cta="homeAccount" role="menuitem"><span class="subcategory account"><img class="hidden-mobile" src="https://static3.avast.com/20001375/web/i/v2/components/navigation/account.svg" alt=""><img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-account.svg" alt="">Account</span></a>
        </li>
      </ul>

    </div>


    
    <div class="second-menu for-business">
      <div class="js-back mobile back">For business</div>



      <ul class="side" role="menubar">
        <li data-second-menu="products">
          <span class="subcategory products arrow" tabindex="0" role="menuitem" aria-expanded="false" aria-controls="solutions">Solutions</span>

          
          <div class="third-menu products solutions" id="navigation-solutions">
            <ul class="block-products">
			
			  
              <li class="no-border">

                <span class="block-header">
                  <span class="header-title">Small Businesses</span>
                  <span class="header-info">11-100</span>
                </span>
                <a class="name" href="/en-us/business/solutions/endpoint-protection" data-role="Nav:MenuItem" data-cta="businessSolutions">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small smb">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-endpoint-protection_white.svg" title="Endpoint Protection">
</div>Endpoint Protection</a>
                <span class="description">
<span class="os win-smb mac-smb servers-smb linux-smb">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span><span class="description-text">Safeguard your data, devices, and apps with <a href="/en-us/business/solutions/next-gen-antivirus" data-role="Nav:MenuItem" data-cta="businessNextGenLink">Next-Gen Antivirus</a>, <a href="/en-us/business/products/patch-management" data-role="Nav:MenuItem" data-cta="businessPatchLink">Patch Management</a>, and <a href="/en-us/business/business-hub/cloud-backup-for-small-business" data-role="Nav:MenuItem" data-cta="businessCloudBackupLink">Cloud Backup</a>.</span>
</span>
            </li>
               
              <li>
                  <span class="block-header">
                    <span class="header-title">Medium and Large Businesses</span>
                    <span class="header-info">101-1000+</span>
                  </span>
                  <a class="name" href="/en-us/business/solutions/all-in-one-security" data-role="Nav:MenuItem" data-cta="businessSolutions">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small smb">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-business-ultimate_white.svg" title="All-In-One Protection">
</div>All-In-One Protection</a>
                  <span class="description">
<span class="os win-smb mac-smb servers-smb">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span></span>
                  <span class="bottom-link">
                    <a href="/en-us/business/solutions/endpoint-protection-for-large-businesses" data-role="Nav:MenuItem" data-cta="businessSolutions">Endpoint Protection</a>						
					<a href="/en-us/business/business-hub/cloud-backup" data-role="Nav:MenuItem" data-cta="businessSolutions">Backup and Recovery</a>			
					<a href="/en-us/business/products/ccleaner " data-role="Nav:MenuItem" data-cta="businessSolutions">Endpoint Optimization</a>						
                    <a href="/en-us/business/solutions/network-security" data-role="Nav:MenuItem" data-cta="businessSolutions">Cloud Network Security</a>
                    <a href="/en-us/business/business-hub" data-role="Nav:MenuItem" data-cta="businessSolutions">Business Hub Security Platform</a>              
                  </span>
              </li>
               
              <li>
                  <span class="block-header">
                    <span class="header-title">Channel Partners</span>
                    <span class="header-info">MSPs, Resellers, Distributors</span>
                  </span>
                  <a class="name" href="/en-us/business/solutions/all-in-one-security-msp" data-role="Nav:MenuItem" data-cta="businessSolutions">

<div
 data-cmp-name="cmp-product-icon" class="product-icon box small smb">
	<img alt="" src="https://static3.avast.com/20001375/web/i/v2/components/icons/product-icons/32x32/product-icon-antivirus-for-servers_white.svg" title="Advanced All-In-One Protection">
</div>Advanced All-In-One Protection</a>
                  <span class="description">
<span class="os win-smb mac-smb">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win.svg" class="img-win" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac.svg" class="img-mac" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android.svg" class="img-android" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios.svg" class="img-ios" alt="Available for iOS">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/win-smb.svg" class="img-win-smb" alt="Available for PC">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/mac-smb.svg" class="img-mac-smb" alt="Available for Mac">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/servers-smb.svg" class="img-servers-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/linux-smb.svg" class="img-linux-smb" alt="">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/android-smb.svg" class="img-android-smb" alt="Available for Android">
  <img src="https://static3.avast.com/20001375/web/i/navigation/os/ios-smb.svg" class="img-ios-smb" alt="Available for iOS">
</span></span>
                  <span class="bottom-link">
                    <a href="/en-us/business/cloudcare/antivirus" data-role="Nav:MenuItem" data-cta="businessSolutions">Endpoint Protection</a><a href="/en-us/business/solutions/network-security" data-role="Nav:MenuItem" data-cta="businessSolutions">Cloud Network Security</a><a href="/en-us/business/cloudcare" data-role="Nav:MenuItem" data-cta="businessSolutions">CloudCare Security Platform</a>
                  </span>
              </li>
            </ul>


            
            <p class="hint">Not sure which solution is right for your business? <a href="/en-us/business/help-me-choose"  data-role="Nav:MenuItem" data-cta="businessSolutionsLink">Help me choose</a></p>
          </div>
          
        </li>

        <li data-second-menu="business-partners">
          <span class="subcategory business-partners arrow" tabindex="0" role="menuitem" aria-expanded="false" aria-controls="partners">Business partners</span>

          
          <div class="third-menu business-partners" id="navigation-partners">
            <ul class="block-products">
              <li>
                <ul>
                  <li class="mobile-link">
                    <a href="/en-us/business/partners" data-role="Nav:MenuItem" data-cta="businessPartners">Become a partner</a>
                  </li>
                  <li class="mobile-link">
                    <a href="/en-us/business/partners/msp" data-role="Nav:MenuItem" data-cta="businessPartners">MSP partners</a>
                  </li>
                  <li class="mobile-link">
                    <a href="/en-us/business/partners/reseller" data-role="Nav:MenuItem" data-cta="businessPartners">Reseller partners</a>
                  </li>
					<li class="mobile-link">
                    <a href="/en-us/business/partners/distributor" data-role="Nav:MenuItem" data-cta="businessPartners">Distributor partners</a>
                  </li>
                  	<li class="mobile-link">
                    <a href="/en-us/affiliates" data-role="Nav:MenuItem" data-cta="affiliates">Affiliates</a>
                  </li>

                  <li class="mobile-link">
                    <a href="/en-us/business/partner-locator" data-role="Nav:MenuItem" data-cta="businessPartners">Partner locator</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          
        </li>

        <li>
          <a href="/en-us/business/resources" data-role="Nav:MenuItem" data-cta="businessResources"><span class="subcategory">Resources</span></a>
        </li>

		<li>
          <a href="/en-us/business/trials" data-role="Nav:MenuItem" data-cta="businessTrials"><span class="subcategory">Trials</span></a>
        </li>
		
        <li>
                  <a class="desktop" href="/en-us/business/store" data-role="Nav:MenuItem" data-cta="businessShop"><span class="subcategory shop">
                    <img class="hidden-mobile" src="https://static3.avast.com/20001375/web/i/v2/components/navigation/cart.svg" alt="">
                    Store
                    </span></a>
        </li>
      </ul>

      <ul class="side mobile-links-top" role="menubar">
        <li class="mobile" role="menuitem">
          <a href="/en-us/business">
            <span class="subcategory"><img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-home.svg" alt="">Home</span>
          </a>
        </li>
         <li role="menuitem">
          <a href="/en-us/business/cloudcare/talk-to-an-expert" data-role="Nav:MenuItem" data-cta="businessContactSales"><span class="subcategory "><img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-sales.svg" alt="">Contact sales</span></a>
        </li>
        <li role="menuitem">
          <a href="/en-us/business/support" data-role="Nav:MenuItem" data-cta="businessSupport"><span class="subcategory support">
            <img class="hidden-mobile" src="https://static3.avast.com/20001375/web/i/v2/components/navigation/support.svg" alt="">
            <img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-support.svg" alt="">Support</span></a>
        </li>
        <li role="menuitem">
          <a class="mobile" href="/en-us/business/store" data-role="Nav:MenuItem" data-cta="businessShop"><span class="subcategory"><img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-store.svg" alt="">            				
            Store

            </span></a>

        </li>
        <li data-second-menu="account">
          <span class="subcategory account arrow" tabindex="0"><img class="hidden-mobile" src="https://static3.avast.com/20001375/web/i/v2/components/navigation/account.svg" alt=""><img class="mobile" src="https://static3.avast.com/20001375/web/i/navigation/mobile/ico-mobile-account.svg" alt="">Account</span>
          
          <div class="third-menu login">
            <ul class="block-products">
              <li>
                <ul>
                  
                  <li class="mobile-link"><a href="https://id.avast.com/?target=https%3A%2F%2Fbusiness.avast.com%3A443%2F#login" data-role="Nav:MenuItem" data-cta="businessAccount">Business Hub</a></li>
                  
                  <li class="mobile-link"><a href="https://us.cloudcare.avg.com/" data-role="Nav:MenuItem" data-cta="businessAccount">CloudCare</a></li>
                  <li class="mobile-link"><a href="https://partners.avast.com/s/login/" data-role="Nav:MenuItem" data-cta="businessAccount">Reseller portal</a></li>
                </ul>
              </li>
            </ul>
          </div>
          
        </li>
      </ul>

    </div>
    
    <div class="second-menu for-partners">
      <div class="js-back mobile back">For partners</div>
      <ul class="side" role="menu">
        <li>
          <a href="/en-us/partners/smartlife" data-role="Nav:MenuItem" data-cta="partnersCarriers"><span class="subcategory">Smart Life</span></a>
        </li>
        <li>
          <a href="/en-us/partners/mobile-security" data-role="Nav:MenuItem" data-cta="partnersAffiliate"><span class="subcategory">Mobile Security</span></a>
        </li>
        <li>
          <a href="/en-us/partners/vpn" data-role="Nav:MenuItem" data-cta="partnersBusiness"><span class="subcategory">VPN</span></a>
        </li>
		<li>
          <a href="/en-us/partners/threat-intelligence" data-role="Nav:MenuItem" data-cta="partnersBusiness"><span class="subcategory">Threat Intelligence</span></a>
        </li>
		<li>
          <a href="/en-us/partners/knowledge" data-role="Nav:MenuItem" data-cta="partnersBusiness"><span class="subcategory shop">Knowledge Center</span></a>
        </li>
      </ul>
    </div>

    
    <div class="second-menu about-us">
      <div class="js-back mobile back">About us</div>

      <ul class="side" role="menu">
        <li data-second-menu="about-us-pages">
          <span class="subcategory about-us-pages arrow">About Avast</span>
		  
          <div class="third-menu about-us-pages">
            <ul class="block-products">
              <li>
                <ul>
                  <li class="mobile-link">
                  	 <a href="/en-us/company-faqs" data-role="Nav:MenuItem" data-cta="aboutCompanyFaqs">Company FAQs</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          
        </li>
        <li>
          <a href="/en-us/careers" data-role="Nav:MenuItem" data-cta="aboutCareers"><span class="subcategory no-line">Careers</span></a>
        </li>
         <li data-second-menu="privacy-pages">
           <span class="subcategory privacy-pages arrow">Privacy</span>
           
          <div class="third-menu privacy-pages">
            <ul class="block-products">
              <li>
                <ul>
                  <li class="mobile-link">
                  	 <a href="/en-us/privacy" data-role="Nav:MenuItem" data-cta="aboutPrivacy">Privacy</a>
                  </li>
                  <li class="mobile-link">
                  	<a href="/c-category-privacy" data-role="Nav:MenuItem" data-cta="categoryPrivacy">Expert guides</a>
                  </li>
                  <li class="mobile-link">
                  	<a href="https://blog.avast.com/topic/privacy" data-role="Nav:MenuItem" data-cta="topicPrivacy">Privacy blogs</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          
        
        <li data-second-menu="press-center">
          <span class="subcategory press-center arrow">Press center</span>

          
          <div class="third-menu press-center">
            <ul class="block-products">
              <li>
                <ul>
                  <li class="mobile-link">
                    	<a href="https://press.avast.com/en-us" data-role="Nav:MenuItem" data-cta="aboutPressReleases">Press releases</a>
                  </li>

                  <li class="mobile-link">
                  	 <a href="https://press.avast.com/events" data-role="Nav:MenuItem" data-cta="aboutPressReleases">Events</a>
                  </li>
                  <li class="mobile-link">
                  	<a href="https://press.avast.com/news" data-role="Nav:MenuItem" data-cta="aboutPressReleases">In the news</a>
                  </li>
                  <li class="mobile-link">
                  	<a href="https://press.avast.com/media-materials" data-role="Nav:MenuItem" data-cta="aboutPressReleases">Media materials</a>
                  </li>
                  <li class="mobile-link">
                  	 <a href="https://press.avast.com/contacts" data-role="Nav:MenuItem" data-cta="aboutPressReleases">PR contacts</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          
        </li>

        <li data-second-menu="investors">
          <span class="subcategory investors arrow">Investors</span>
          
          <div class="third-menu investors">
            <ul class="block-products">
              <li>
                <span class="name">Our story</span>
                <ul>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/our-story/at-a-glance/" data-role="Nav:MenuItem" data-cta="aboutInvestors">At a glance</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/our-story/strategy/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Strategy</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/our-story/technology-expertise/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Technology expertise</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/our-story/leadership/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Leadership</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/our-story/history/" data-role="Nav:MenuItem" data-cta="aboutInvestors">History</a>
                  </li>
                </ul>
              </li>
              <li>
                <span class="name">Investors</span>
                <ul>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/overview/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Overview</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/growth-opportunity/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Growth &amp; competitive advantage</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/ipo-information/" data-role="Nav:MenuItem" data-cta="aboutInvestors">IPO information</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/regulatory-news/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Regulatory news</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/share-price-and-tools/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Share price &amp; tools</a></li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/corporate-governance/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Corporate governance</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/investor-contacts/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Investor contacts</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/financial-calendar/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Financial calendar</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/results-reports-and-presentations/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Results, reports &amp; presentations</a>
                  </li>
                  <li class="mobile-link"><a href="https://investors.avast.com/investors/analyst-consensus/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Analyst consensus</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/investors/shareholder-information/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Shareholder information</a>
                  </li>
                  <li class="mobile-link">
                    <a href="https://investors.avast.com/contact-us/" data-role="Nav:MenuItem" data-cta="aboutInvestors">Contact us</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          
        </li>
      </ul>

      <ul class="side" role="menubar">
        <li>
          <a href="/en-us/awards-certifications" data-role="Nav:MenuItem" data-cta="aboutAwards"><span class="subcategory">Awards</span></a>
        </li>
		
		 <li data-second-menu="diversity">
          <span class="subcategory diversity arrow">Diversity & Inclusion</span>
          
          <div class="third-menu diversity">
            <ul class="block-products">
              <li>
                <ul>
                  <li class="mobile-link">
                  	 <a href="/en-us/diversity" data-role="Nav:MenuItem" data-cta="aboutDiversity">Diversity & Inclusion</a>
                  </li>
				  <li class="mobile-link">
                  	 <a href="/en-us/accessibility" data-role="Nav:MenuItem" data-cta="aboutAccessibility">Accessibility</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
          
        </li>
		
        <li>
          <a href="/en-us/contacts" data-role="Nav:MenuItem" data-cta="aboutContact"><span class="subcategory">Contact us</span></a>
        </li>
      </ul>
    </div>

    <ul class="second-menu blogs">
      <li class="js-back js-blog mobile back">Blogs</li>

      <li>
        <a href="https://blog.avast.com" data-role="Nav:MenuItem" data-cta="blogsBlog">
          <span class="txt-blogs-title">Avast Blog</span>
          <span class="txt-blogs-description">Read about recent news from the security world</span>
        </a>
      </li>

      <li>
        <a href="/c-academy" data-role="Nav:MenuItem" data-cta="blogsAcademy">
          <span class="txt-blogs-title">Avast Academy</span>
          <span class="txt-blogs-description">Expert tips and guides about digital security and privacy</span>
        </a>
      </li>

      <li>
        <a href="https://decoded.avast.io/" data-role="Nav:MenuItem" data-cta="blogsDecoded">
          <span class="txt-blogs-title">Avast Decoded</span>
          <span class="txt-blogs-description">In-depth technical articles regarding security threats</span>
        </a>
      </li>

      <li>
        <a href="https://forum.avast.com/" data-role="Nav:MenuItem" data-cta="blogsForum">
          <span class="txt-blogs-title">Avast Forum</span>
          <span class="txt-blogs-description">Discuss with the community</span>
        </a>
      </li>
    </ul>

    


  </nav>

</div>
</header>

	
<section class="region-selector" role="dialog" aria-label="Region selector">
  <button class="region-selector-close">&nbsp;</button>
  
  <h1 class="reader-only">List of available regions</h1>
  
  <div class="custom-regions" id="lang-selector-navigation">

    <div class="main-regions">
      <h5 class="reader-only">Main regions</h5>
      <ul>
        <li class="region en-ww"><a lang="en" class="with-flag" href="/index">Worldwide (English)</a></li>
        <li class="region en-eu"><a lang="en" class="with-flag" href="/en-eu/index">Europe (English)</a></li>
        <li class="region es-ww"><a lang="es" class="with-flag" href="/es-ww/index">América Latina (español)</a></li>
      </ul>
    </div>

    <div class="area regions-0">
      <h5 class="js-regions-toggle subcategory arrow">AMERICAS</h5>

      <div class="js-regions">
        <ul>
          <li class="region es-ar"><a lang="es" class="with-flag" href="/es-ar/index">Argentina</a></li>
          <li class="region pt-br"><a lang="pt" class="with-flag" href="/pt-br/index">Brasil</a></li>
          <li class="region en-ca"><a lang="en" class="with-flag" href="/en-ca/index">Canada (English)</a></li>
          <li class="region fr-ca"><a lang="fr" class="with-flag" href="/fr-ca/index">Canada (français)</a></li>
          <li class="region es-cl"><a lang="es" class="with-flag" href="/es-cl/index">Chile</a></li>
          <li class="region es-co"><a lang="es" class="with-flag" href="/es-co/index">Colombia</a></li>
          
          <li class="region es-us"><a lang="es" class="with-flag" href="/es-us/index">EE.UU. (español)</a></li>
          <li class="region es-mx"><a lang="es" class="with-flag" href="/es-mx/index">México</a></li>
          <li class="region en-us"><a class="with-flag" href="/en-us/index">USA (English)</a></li>
        </ul>
        <ul class="other">
          <li class="region es-ww"><a lang="es" class="with-flag" href="/es-ww/index">América Latina (español)</a></li>
        </ul>
      </div>
    </div>

    <div class="area regions-1">
      <h5 class="js-regions-toggle subcategory arrow">EUROPE, MIDDLE EAST &amp; AFRICA</h5>

      <div class="js-regions">
        <ul>
          <li class="region nl-be"><a lang="nl" class="with-flag" href="/nl-be/index">België (Nederlands)</a></li>
          <li class="region fr-be"><a lang="fr" class="with-flag" href="/fr-be/index">Belgique (français)</a></li>
          <li class="region cs-cz"><a lang="cs" class="with-flag" href="/cs-cz/index">Česká republika</a></li>
          <li class="region da-dk"><a lang="da" class="with-flag" href="/da-dk/index">Danmark</a></li>
          <li class="region de-de"><a lang="de" class="with-flag" href="/de-de/index">Deutschland </a></li>
          <li class="region es-es"><a lang="es" class="with-flag" href="/es-es/index">España</a></li>
          <li class="region fr-fr"><a lang="fr" class="with-flag" href="/fr-fr/index">France</a></li>
          <li class="region it-it"><a lang="it" class="with-flag" href="/it-it/index">Italia </a></li>
          <li class="region hu-hu"><a lang="hu" class="with-flag" href="/hu-hu/index">Magyarország</a></li>
          <li class="region nl-nl"><a lang="nl" class="with-flag" href="/nl-nl/index">Nederland</a></li>
          <li class="region no-no"><a lang="no" class="with-flag" href="/no-no/index">Norge</a></li>
          <li class="region pl-pl"><a lang="pl" class="with-flag" href="/pl-pl/index">Polska</a></li>
          <li class="region pt-pt"><a lang="pt" class="with-flag" href="/pt-pt/index">Portugal</a></li>
          <li class="region de-ch"><a lang="de" class="with-flag" href="/de-ch/index">Schweiz (Deutsch)</a></li>
          <li class="region cs-sk"><a lang="cs" class="with-flag" href="/cs-sk/index">Slovensko (česky)</a></li>
          <li class="region en-za"><a lang="en" class="with-flag" href="/en-za/index">South Africa</a></li>
        </ul>
        <ul>
          <li class="region fr-ch"><a lang="fr" class="with-flag" href="/fr-ch/index">Suisse (français)</a></li>
          <li class="region fi-fi"><a lang="fi" class="with-flag" href="/fi-fi/index">Suomi</a></li>
          <li class="region sv-se"><a lang="sv" class="with-flag" href="/sv-se/index">Sverige</a></li>
          <li class="region tr-tr"><a lang="tr" class="with-flag" href="/tr-tr/index">Türkiye</a></li>
          <li class="region en-ae"><a lang="en" class="with-flag" href="/en-ae/index">United Arab Emirates</a></li>
          <li class="region en-gb"><a lang="en" class="with-flag" href="/en-gb/index">United Kingdom</a></li>
          <li class="region el-gr"><a lang="el" class="with-flag" href="/el-gr/index">Ελλάδα</a></li>
          <li class="region he-il"><a lang="he" class="with-flag" href="/he-il/index">ישראל</a></li>
          <li class="region ru-kz"><a lang="ru" class="with-flag" href="/ru-kz/index">Казахстан</a></li>
          <li class="region ro-ro"><a lang="ro" class="with-flag" href="/ro-ro/index">România</a></li>
          <li class="region ru-ru"><a lang="ru" class="with-flag" href="//www.avast.ru/index">Россия</a></li>
          <li class="region uk-ua"><a lang="uk" class="with-flag" href="//www.avast.ua/index">Україна (українська)</a></li>
          <li class="region ru-ua"><a lang="ru" class="with-flag" href="//www.avast.ua/ru-ua/index">Украина (русский)</a></li>
          <li class="region ar-sa"><a lang="ar" class="with-flag" href="/ar-sa/index">المملكة العربية السعودية</a></li>
          <li class="region ar-ww"><a lang="ar" class="with-flag" href="/ar-ww/index">الدول العربية</a></li>
        </ul>
        <ul class="other">
          <li class="region en-eu"><a lang="en" class="with-flag" href="/en-eu/index">Europe (English)</a></li>
        </ul>
      </div>
    </div>

    <div class="area regions-2">
      <h5 class="js-regions-toggle subcategory arrow">ASIA &amp; PACIFIC</h5>

      <div class="js-regions">
        <ul>
          <li class="region en-au"><a lang="en" class="with-flag" href="/en-au/index">Australia</a></li>
          <li class="region en-in"><a lang="en" class="with-flag" href="/en-in/index">India</a></li>
          <li class="region hi-in"><a lang="hi" class="with-flag" href="/hi-in/index">इंडिया (हिंदी)</a></li>
          <li class="region en-id"><a lang="en" class="with-flag" href="/en-id/index">Indonesia (English)</a></li>
          <li class="region id-id"><a lang="id" class="with-flag" href="/id-id/index">Indonesia (Bahasa Indonesia)</a></li>
          <li class="region en-my"><a lang="en" class="with-flag" href="/en-my/index">Malaysia (English)</a></li>
          <li class="region ms-my"><a lang="ms" class="with-flag" href="/ms-my/index">Malaysia (Bahasa Melayu)</a></li>
          <li class="region en-nz"><a lang="en" class="with-flag" href="/en-nz/index">New Zealand</a></li>
          <li class="region en-ph"><a lang="en" class="with-flag" href="/en-ph/index">Philippines (English)</a></li>
          <li class="region tl-ph"><a lang="tl" class="with-flag" href="/tl-ph/index">Pilipinas (Filipino)</a></li>
        </ul>
        <ul>
          <li class="region en-sg"><a lang="en" class="with-flag" href="/en-sg/index">Singapore</a></li>
          <li class="region vi-vn"><a lang="vi" class="with-flag" href="/vi-vn/index">Việt Nam</a></li>
          <li class="region ja-jp"><a lang="ja" class="with-flag" href="//www.avast.co.jp/index">日本語 </a></li>
          <li class="region ko-kr"><a lang="ko" class="with-flag" href="/ko-kr/index">대한민국</a></li>
          <li class="region zh-cn"><a lang="zh" class="with-flag" href="/zh-cn/index">简体中文</a></li>
          <li class="region zh-tw"><a lang="zh" class="with-flag" href="/zh-tw/index">繁體中文</a></li>
          <li class="region th-th"><a lang="th" class="with-flag" href="/th-th/index">ประเทศไทย</a></li>
        </ul>
        <ul class="other">
          <li class="region en-ww"><a lang="en" class="with-flag" href="/index">Worldwide (English)</a></li>
        </ul>
      </div>
    </div>
  </div>
</section>


    
    <div id="content-holder" tabindex="-1">  
      <style>
  .search-bar-content  {
  	margin-bottom: 50px;
    position: relative;
    width: 80%;
    margin: 0px auto 50px;
  }
  
  .search-bar-content input[type="text"] {
    width: 100%;
    padding: 25px 20px;
    background-position: right 20px center;
    border-radius: 4px;
    background: #fff;
    border: 1px solid #E1E2E5;
    color: #767683;
    box-sizing: border-box;
    min-height: 75px;
  }
  
  .search-bar-content input[type="submit"] {
  	position: absolute;
        width: 65px;
    height: 65px;
    background-image: url('https://support.avast.com/resource/1561019326000/avast_resources/img/search-box/search-icon.svg');
    background-repeat: no-repeat;
    background-color: transparent;
    background-position: center center;
    position: absolute;
    top: 0;
    right: 10px;
    cursor: pointer;
    border-radius: 3px;
    border: none;
    text-indent: -9999px;
  }
  li.nav-bar-section-tab.search {
      	display: none!important;
      }
  
  
</style>
<div id="error404" class="bg-blue-grad">
  <div class="AVsizer">
    <h1>Message from Avast I.T. Department (404 page)</h1>
    <h3>There seems to be a problem with this page. In the meantime, click below.</h3>
    <div id="it404"> 
    
      
      <a class="button blue big" href="/en-us/index"><span>Go to Homepage</span></a>
      <img src="https://static3.avast.com/20001375/web/i/error/it404.png">
    </div>
  </div>
</div>  
    </div>
    
	<div class="chrome-banner inverse" style="display:none"
 id="offer-chrome" data-cmp-name="cmp-chrome-banner">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-12 col-xl-10">
				<div class="chrome-banner__content">
					<div class="chrome-banner__info">
						<div class="chrome-banner__ico">
							<img src="https://static3.avast.com/20001375/web/i/v2/components/icons/browsers/chrome.svg" alt="">
						</div>
						<h4 class="chrome-banner__title">
							Avast recommends using <br> the <b>FREE</b> Chrome&trade; internet browser.
						</h4>
					</div>
					<div class="chrome-banner__cta">
						<div class="d-none d-md-block">
							

<div
 data-cmp-name="cmp-button" class="btn-wrapper ">
		<a

		 href="https://www.google.com/chrome/" data-cms-component="button--btn-lg btn-outline-secondary" data-role="cta-link" class="btn btn-lg btn-outline-secondary">

				<span>Download Chrome</span>

	
		</a>
	
	
</div>
						</div>
						<a href="https://play.google.com/store/apps/details/Google_Chrome_Fast_Secure?id=com.android.chrome" class="d-block d-md-none chrome-banner__play" target="_blank" rel="noopener noreferrer" title="Download Chrome">








	<img src="https://static3.avast.com/20001375/web/i/v2/components/store-badge/google-play/google-play.svg" alt="" data-cmp-name="cmp-store-badge-img" class="storebadge-google ">



</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
    

<div class="bottom-links inverse" data-cmp-name="cmp-footer-links">
	<div class="container">

		
		<div class="row internal">

			
			<div class="col-md-12 col-lg-4 select-region">

				
				<img class="logo-avast" src="https://static3.avast.com/20001375/web/i/v2/footer/avast-logo-inverse.svg" alt="Avast">

				
				<p class="region en-us">
					<a class="select-region-button with-flag js-language-selector-trigger" aria-label="United States (English) opens dialog" tabindex="0">
						<span>United States (English)</span><img src="https://static3.avast.com/20001375/web/i/v2/components/arrow-s-down-white.svg" alt="">
					</a>
				</p>

			</div>

			
			<div class="col-md-3 col-lg-2 links sec1">
				<p class="tagline-medium">For home</p>
				<ul class="list-unstyled">
					<li><a href="//support.avast.com" target="_blank" rel="noopener noreferrer">Support</a></li>
					<li><a href="/en-us/free-antivirus-download">Security</a></li>
					<li><a href="/en-us/secureline-vpn" target="_blank" rel="noopener noreferrer">Privacy</a></li>
					<li><a href="/en-us/cleanup">Performance</a></li>
						<li><a href="https://blog.avast.com" target="_blank" rel="noopener noreferrer">Blog</a></li>
						<li><a href="//forum.avast.com/" target="_blank" rel="noopener noreferrer">Forum</a></li>

				</ul>
			</div>

			
			<div class="col-md-3 col-lg-2 links sec2">
				<p class="tagline-medium">For business</p>
				<ul class="list-unstyled">
					<li><a href="/en-us/business/support">Business support</a></li>
					<li><a href="/en-us/business">Business products</a></li>
					<li><a href="/en-us/business/become-a-partner">Business partners</a></li>
						<li><a href="https://blog.avast.com/topic/business-security">Business blog</a></li>
					<li><a href="/en-us/affiliates">Affiliates</a></li>
				</ul>
			</div>

			
			<div class="col-md-3 col-lg-2 links sec3">
				<p class="tagline-medium">For partners</p>
				<ul class="list-unstyled">
					<li><a href="/en-us/mno">Mobile Carriers</a></li>
				</ul>
			</div>


			
			
			<div class="col-md-3 col-lg-2 links sec4">
				<p class="tagline-medium">Company</p>
				<ul class="list-unstyled">
					<li><a href="/en-us/contacts">Contact Us</a></li>
						<li><a href="//investors.avast.com/" target="_blank" rel="noopener noreferrer">Investors</a></li>
					<li><a href="/en-us/careers">Careers</a></li>
					<li><a href="//press.avast.com/en-us" target="_blank" rel="noopener noreferrer">Press Center</a></li>
					<li><a href="/en-us/diversity">Responsibility</a></li>
					<li><a href="/en-us/technology">Technology</a></li>
						<li><a href="/en-us/online-research">Research Participation</a></li>
				</ul>
			</div>
			

			
			<div class="social">
				<div class="social-icons"
 data-cmp-name="cmp-social-icons">
			<a href="https://www.facebook.com/avast" title="Facebook" aria-label="Facebook" class="social-icons__item medium">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
					<path fill="#A8A4C3" fill-rule="evenodd" d="M20.575 16.347H17.86V25h-3.992v-8.653H12v-3.3h1.868v-2.151c-.072-1.064.338-2.106 1.121-2.852.784-.746 1.863-1.122 2.955-1.03h2.972v3.22h-2.123c-.244-.01-.48.086-.643.262-.164.175-.24.413-.206.648v1.9H21l-.425 3.303z"></path>
				</svg>
			</a>
			<a href="https://www.instagram.com/avast" title="Instagram" aria-label="Instagram" class="social-icons__item medium">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
					<path fill="#A8A4C3" fill-rule="evenodd" d="M27 11.492c.001-.917-.165-1.826-.49-2.683-.242-.74-.661-1.41-1.221-1.952-.54-.561-1.21-.981-1.952-1.224-.858-.326-1.768-.492-2.686-.49-1.543-.134-3.092-.173-4.64-.12-1.505-.05-3.012-.01-4.513.121-.918-.001-1.828.165-2.686.49-.742.241-1.414.66-1.957 1.219-.56.541-.98 1.211-1.222 1.952-.325.858-.49 1.77-.488 2.687-.135 1.5-.176 3.005-.122 4.51-.05 1.504-.01 3.01.122 4.508-.002.917.164 1.827.49 2.684.242.74.66 1.41 1.22 1.952.543.56 1.213.978 1.954 1.22.858.325 1.769.49 2.686.49 1.5.131 3.008.172 4.514.121 1.505.054 3.012.013 4.513-.121.917 0 1.828-.165 2.686-.49 1.49-.514 2.661-1.684 3.175-3.173.326-.857.492-1.766.49-2.683 0-1.22.122-1.586.122-4.51L27 11.492zm-2.076 8.9c.009.71-.115 1.413-.366 2.075-.425.913-1.158 1.647-2.071 2.073-.663.25-1.367.375-2.076.366-1.1 0-1.465.121-4.396.121-1.466.056-2.934.015-4.395-.121-.711.01-1.418-.114-2.084-.366-.912-.425-1.645-1.158-2.071-2.069-.25-.662-.375-1.366-.366-2.074 0-1.098-.122-1.464-.122-4.392-.055-1.465-.014-2.931.122-4.391-.01-.71.114-1.417.366-2.082.213-.45.502-.862.854-1.216.286-.426.72-.73 1.217-.853.664-.251 1.37-.375 2.08-.366 1.099 0 1.465-.122 4.395-.122 1.467-.055 2.935-.014 4.396.122.709-.009 1.413.115 2.076.366.913.424 1.648 1.157 2.075 2.069.25.662.375 1.366.366 2.074 0 1.098.122 1.464.122 4.392.055 1.466.014 2.934-.122 4.395zM16.01 10.392c-3.101 0-5.615 2.512-5.615 5.61 0 3.1 2.514 5.611 5.615 5.611 3.102 0 5.616-2.512 5.616-5.61.025-1.496-.559-2.938-1.617-3.995-1.059-1.058-2.502-1.641-3.999-1.616zm0 9.27c-.976.018-1.918-.362-2.61-1.052-.69-.69-1.07-1.632-1.052-2.608-.018-.975.362-1.916 1.053-2.607.69-.69 1.633-1.07 2.61-1.052.976-.017 1.918.362 2.609 1.052.69.69 1.07 1.632 1.053 2.607.018.976-.362 1.917-1.053 2.607-.69.69-1.633 1.07-2.61 1.053zm5.86-10.856c-.741 0-1.342.6-1.342 1.342 0 .74.6 1.341 1.343 1.341.741 0 1.343-.6 1.343-1.341-.007-.739-.604-1.336-1.343-1.342z"></path>
				</svg>
			</a>
			<a  href="https://twitter.com/avast_antivirus" title="Twitter" aria-label="Twitter" class="social-icons__item medium">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
					<path fill="#A8A4C3" fill-rule="evenodd" d="M24.762 11.5v.587c.012 4.72-2.547 9.07-6.668 11.334-4.122 2.265-9.146 2.082-13.094-.475.389 0 .681.097 1.071.097 2.051.027 4.047-.665 5.646-1.956-1.916-.042-3.595-1.298-4.186-3.13.285.08.581.113.876.097.396-.018.789-.083 1.169-.196-2.089-.421-3.594-2.26-3.603-4.401v-.098c.595.334 1.267.503 1.947.489-1.251-.823-2.017-2.214-2.044-3.717-.015-.79.187-1.569.584-2.25 2.285 2.86 5.698 4.575 9.345 4.695 0-.293-.097-.684-.097-1.076.029-2.473 2.017-4.472 4.478-4.5 1.262-.01 2.467.524 3.31 1.468.995-.196 1.95-.56 2.823-1.077-.327 1.054-1.018 1.956-1.947 2.544.897-.136 1.778-.365 2.628-.684-.646.844-1.398 1.6-2.238 2.249z"></path>
				</svg>
			</a>
			<a href="https://www.youtube.com/avast" title="YouTube" aria-label="Youtube" class="social-icons__item medium">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
					<path fill="#A8A4C3" fill-rule="evenodd" d="M16 7c2.51 0 5.022.112 7.533.336C26.628 7.612 29 10.205 29 13.312v6.376c0 3.107-2.372 5.7-5.467 5.976C21.022 25.888 18.51 26 16 26c-2.51 0-5.022-.112-7.533-.336C5.372 25.388 3 22.795 3 19.688v-6.376c0-3.107 2.372-5.7 5.467-5.976C10.978 7.112 13.49 7 16 7zm-3 6v7l7-3.5-7-3.5z"></path>
				</svg>
			</a>
</div>
			</div>

		</div>
		

	</div>
</div>



<div class="footer inverse web" data-cmp-name="cmp-footer">
	<div class="container">

		<div class="row justify-content-between">

			
			<div class="col-12  copyright">
				<p>1988-2021 Copyright Avast Software s.r.o.</p>

			</div>

			
			<div class="col-12 middle">
				<a href="/en-us/privacy-policy">Privacy policy</a>
				<a href="/en-us/legal">Legal</a>

				<a href="/coordinated-vulnerability-disclosure">Report vulnerability</a>
				<a href="/bug-bounty">Contact security</a>

				<a href="https://static3.avast.com/20001375/web/o/legal/2020-2021-ModernSlaveryStatement.pdf" target="_blank" rel="noopener">Modern Slavery Statement</a>
					<a href="https://press.avast.com/privacy-listing/en/do-not-sell" target="_blank" rel="noopener">Do not sell my info</a>
					<button id="ot-sdk-btn" class="ot-sdk-show-settings"></button>
			</div>

			
				<div class="col-12  right">
				</div>

		</div>
	</div>
</div>



    <div class="js-popup-dtp popup-dtp" id="downloadPopup" data-behavior="downloadPopup" data-role="popup" style="display: none">
  
   
  <div data-browser="chrome">
  
<div class="dtp-arrow">
    <div class="dtp-arrow-header"></div>
    <div class="dtp-arrow-body">
        <p>Click this file to start installing Avast</p>
    </div>
    <div class="dtp-arrow-footer"></div>
</div>


    <div class="js-dtp-close dtp-close">
      <span class="text">Close</span>
      <span class="cross"></span>
    </div>

    <div class="content">
      
      <div id="dwnTy-download-popup" class="dwnTy">
        <div class="AVsizer">

          <div class="center">
            <h1>Follow these steps to complete your Avast installation:</h1>
            
            <p class="noteProgress" style="display: none;"><span></span></p>
            <p class="note noteHidden" style="display: inline-block;"><strong>Note</strong>: If your download did not start automatically, please <a href="/en-us/download-thank-you.php?product=FAV-ONLINE&locale=en-us" data-bi-download-name="FAV-ONLINE" class="bi-download-link" data-role="download-link" data-download-name="FAV-ONLINE">click here</a>.</p>
          </div>
          <div class="boxes">

            <div class="row">
              <div class="span4">
                <div class="box">
                  <span class="step"><span>1</span></span>
                  <div class="box-in">
                    <div class="same-height">
                      <h2>Run the Avast installer</h2>
                      <p>Click the downloaded file at the bottom left corner of your screen.</p>
                    </div>
                    <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/ch-step1.png" alt="">
                  </div>
                </div>
              </div>
              <div class="span4">
                <div class="box">
                  <span class="step"><span>2</span></span>
                  <div class="box-in">
                    <div class="same-height">
                      <h2>Confirm the installation</h2>
                      <p>Click "Yes" on the system dialog window to approve the start of your Avast installation.</p>
                    </div>
                    <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/ch-step2.png" alt="">
                  </div>
                  
                </div>
              </div>
              <div class="span4">
                <div class="box">
                  <span class="step"><span>3</span></span>
                  <div class="box-in">
                    <div class="same-height">
                      <h2>Follow setup instructions</h2>
                      <p>Click the button in the installer window to begin installation.</p>
                    </div>
                    <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/express-install.png" alt="">
                  </div>
                  
                </div>
              </div>
            </div>        

            <div class="clear"> </div>
          </div>

          <p class="offlinep" style="display:none">
            If you need to install Avast on a PC without an internet connection,<br> you can download the offline installer <a href="/en-us/download-thank-you.php?product=FAV-ONLINE-DIRECT&locale=en-us" data-bi-download-name="FAV-ONLINE-DIRECT" class="bi-download-link" data-role="download-link" data-download-name="FAV-ONLINE">here</a>.
          </p>  

          <div class="techSupport">
            <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/icon-phone.svg" alt="">
            <p><b>Need help?</b> Please call <span>855-745-3255</span></p>
          </div>

        </div>
      </div>
      
    </div>
    </div>
    
    
    <div data-browser="firefox" id="popup-dtp-firefox" style="display: none">
      <div class="dtp-arrow-title"><p>Click this file to start <br>installing Avast</p></div>
  <div class="dtp-arrow firefox">
    <div class="dtp-arrow-body">

      
      <div id="animation_container" style="background-color:rgba(36, 44, 65, 1.00); width:56px; height:56px">
        <canvas id="canvas" width="56" height="56"></canvas>
        <div id="dom_overlay_container" 
             style="pointer-events:none; overflow:hidden; width:56px; height:56px; position: absolute; left: 0px; top: 0px; display: block;">
        </div>
      </div>
      

      <img class="arrow-top" src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/dtp-ff-arrow-website-698.svg" alt="">
    </div>
  </div>


  <div class="js-dtp-close dtp-close">
    <span class="text">CLOSE</span>
    <span class="cross"></span>
  </div>

  <div class="content">
    
    <div id="dwnTy-download-popup-firefox" class="dwnTy">
      <div class="AVsizer">

        <div class="center">
          <h1>Almost done!</h1>
          <p class="info">Follow these 3 easy steps to complete your Avast installation</p>


          <p class="noteProgress" style="display: none;"><span></span></p>
          <p class="note noteHidden firefox" style="display: inline-block;"><strong>Note</strong>: If your download did not start automatically, please <a href="/en-us/download-thank-you.php?product=FAV-ONLINE&locale=en-us" data-bi-download-name="FAV-ONLINE" class="bi-download-link" data-role="download-link" data-download-name="FAV-ONLINE">click here</a>.</p>
        </div>
        <div class="boxes">

          <div class="row">
            <div class="span4">
              <div class="box firefox">
                <span class="step"><span>Step 1</span></span>
                <div class="box-in">
                  <div class="same-height">
                    <h2>Run the Avast installer</h2>
                    <p>Click the downloaded file at the <br/>top right corner of your screen.</p>
                  </div>
                </div>
                <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/dtp-ff-step1-website-698.png" alt="">
              </div>
            </div>
            <div class="span4">
              <div class="box firefox">
                <span class="step"><span>Step 2</span></span>
                <div class="box-in">
                  <div class="same-height">
                    <h2>Confirm the installation</h2>
                    <p>Click "Yes" on the system dialog window to approve the start of your Avast installation.</p>
                  </div>
                </div>
                <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/dtp-ff-step2-website-698.png" alt="">
              </div>
            </div>
            <div class="span4">
              <div class="box firefox">
                <span class="step"><span>Step 3</span></span>
                <div class="box-in">
                  <div class="same-height">
                    <h2>Follow setup instructions</h2>
                    <p>Click the button in the installer <br/>window to begin installation.</p>
                  </div>
                </div>
                <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/dtp-ff-step3-website-698.png" alt="">
              </div>
            </div>
          </div>        

          <div class="clear"> </div>
        </div>

        <p class="offlinep" style="display:none">
         Follow setup instructions
        </p>  

        <div class="techSupport">
          <img src="https://static3.avast.com/20001375/web/i/mkt/thank-you/v4/icon-phone.svg" alt="">
          <p><b>Need help?</b> Please call <span>855-745-3255</span></p>
        </div>

      </div>
    </div>
    
  </div>
  	</div>
    
  
  </div>

    
    
    <script>
	window.avastGlobals = window.avastGlobals || {};	
	window.avastGlobals.web = {
				domain: "www.avast.com",
				pathFromRoot: "en-us/error-page.php",
				fileName: "error-page.php",
				locale: "en-us",
				ulocale: "/en-us",
				RootPath: "../",
				language: "en",
				numberDecimalSeparator: ".",
				numberThousandSeparator: ",",
				responsive: true,
				contentGroup: '',
				pageName: 'en-us | en-us/error-page.php',
      			'notification-overlay-for-wrong-download': {
                    'this-is-a-temp-index': {
      '					alternative-links': {
                              android: '/download-thank-you.php?product=AMS',
                              mac: '/download-thank-you.php?product=MAC-FREE-ONLINE',
                              ios: '/download-thank-you.php?product=IMS'
                        },
                          'alternative-tracking': {
                              android: 'AMS',
                              mac: 'MAC-FREE-ONLINE',
                              ios: 'IMS'
                        },
                          'button-selector': '[href*=\"download-thank-you.php?product=FAV-ONLINE\"]',
                          'product-id': 'FAV-ONLINE',
                          'supported-platform': 'windows'
                        },
                  'free-antivirus-download-v2': {
                      'alternative-links': {
                          android: '/download-thank-you.php?product=AMS',
                          mac: '/download-thank-you.php?product=MAC-FREE-ONLINE',
                          ios: '/download-thank-you.php?product=IMS'
                      },
                      'alternative-tracking': {
                          android: 'AMS',
                          mac: 'MAC-FREE-ONLINE',
                          ios: 'IMS'
                      },
                      'button-selector': '[href*=\"download-thank-you.php?product=FAV-ONLINE\"]',
                      'product-id': 'FAV-ONLINE',
                      'supported-platform': 'windows'
                     }
                }
			};
</script>
    <script src="https://static3.avast.com/20001375/web/j/v2/vendor/cash.js"></script>
<script src="https://static3.avast.com/20001375/web/j/v2/avast.js"></script>
<script src="https://static3.avast.com/20001375/web/j/v2/vendor/bootstrap-native.js"></script>


<script src="https://static3.avast.com/20001375/web/j/lib/createjs/bundle.js"></script>
<script src="https://static3.avast.com/20001375/web/j/dtp-overlay-firefox.js"></script>



<script type="text/javascript" src="https://resources.digital-cloud.medallia.eu/wdceu/82320/onsite/embed.js" async></script>

    
    <script src="https://static3.avast.com/20001375/web/j/v2/vendor/aos.js"></script>
    
    
    
    
  </body>
<!-- cached: 2021-08-10 13:08:54, 381.51121139526, 332.0209980011, 5.8701038360596, 001.nyc1 --></html>